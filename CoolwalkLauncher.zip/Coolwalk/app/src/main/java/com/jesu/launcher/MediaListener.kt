package com.jesu.launcher

import android.service.notification.NotificationListenerService

// Solo existe para que Android permita leer la sesión de música activa (YouTube Music, etc.).
class MediaListener : NotificationListenerService()
