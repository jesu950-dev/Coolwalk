package com.jesu.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Velocímetro: círculo con anillo que se llena de 0 a 160 km/h. */
class SpeedRing(ctx: Context) : View(ctx) {
    var value = 0f
        set(v) { field = v; invalidate() }
    var maxValue = 160f
    var bgColor = 0xCC14173F.toInt()
    var trackColor = 0xFF3E4469.toInt()
    var fillColor = 0xFF46AFFF.toInt()
    var textColor = 0xFFFFFFFF.toInt()
    var softColor = 0xFFC8CDEB.toInt()

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val numP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val unitP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        val stroke = s * 0.085f
        bgP.color = bgColor
        c.drawCircle(s / 2f, s / 2f, s / 2f, bgP)
        val pad = stroke * 1.4f
        rect.set(pad, pad, s - pad, s - pad)
        arcP.strokeWidth = stroke
        arcP.color = trackColor
        c.drawArc(rect, 135f, 270f, false, arcP)
        arcP.color = fillColor
        c.drawArc(rect, 135f, 270f * (value / maxValue).coerceIn(0f, 1f), false, arcP)
        numP.color = textColor
        numP.textSize = s * 0.32f
        c.drawText(Math.round(value).toString(), s / 2f, s * 0.56f, numP)
        unitP.color = softColor
        unitP.textSize = s * 0.13f
        c.drawText("km/h", s / 2f, s * 0.74f, unitP)
    }
}
