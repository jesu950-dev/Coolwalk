package com.carlauncher.coolwalk

import android.Manifest
import android.animation.ValueAnimator
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.concurrent.Executors

private data class AppTheme(
    val name: String, val bg: Int, val card: Int, val accent: Int, val text: Int,
    val m1: Int, val m2: Int, val m3: Int, val blobA: Int, val blobB: Int,
    val infoA: Int, val infoB: Int
)

private val THEMES = listOf(
    AppTheme("Aurora (teal, morado, magenta)", 0xFF070914.toInt(), 0xFF0E1024.toInt(), 0xFF00F5D4.toInt(), 0xFFE5E5E5.toInt(),
        0xFF0B4F5C.toInt(), 0xFF4C1D95.toInt(), 0xFF86198F.toInt(), 0xFFC026D3.toInt(), 0xFF00C8BE.toInt(), 0xFF14123C.toInt(), 0xFF5B1A78.toInt()),
    AppTheme("Negro Azulado", 0xFF0A0E17.toInt(), 0xFF111827.toInt(), 0xFF38BDF8.toInt(), 0xFFE5E5E5.toInt(),
        0xFF0B2545.toInt(), 0xFF13315C.toInt(), 0xFF1E6091.toInt(), 0xFF3B82F6.toInt(), 0xFF0EA5E9.toInt(), 0xFF0F1B33.toInt(), 0xFF13315C.toInt()),
    AppTheme("Azul + Ámbar", 0xFF080B12.toInt(), 0xFF0D1320.toInt(), 0xFFFFB454.toInt(), 0xFFE8EDF5.toInt(),
        0xFF0B2545.toInt(), 0xFF4A2540.toInt(), 0xFF9A3412.toInt(), 0xFFDC2626.toInt(), 0xFFF59E0B.toInt(), 0xFF101A30.toInt(), 0xFF4A2540.toInt()),
    AppTheme("Carbón Turquesa", 0xFF121212.toInt(), 0xFF1C1C1E.toInt(), 0xFF00F5D4.toInt(), 0xFFE5E5E5.toInt(),
        0xFF005F73.toInt(), 0xFF4A1A7A.toInt(), 0xFF7B2CBF.toInt(), 0xFFD81B8A.toInt(), 0xFF00828A.toInt(), 0xFF1C1C1E.toInt(), 0xFF2A2A30.toInt())
)

private class AppItem(val label: String, val ri: ResolveInfo)

class MainActivity : AppCompatActivity() {

    companion object {
        // >>> API key de OpenWeatherMap <<<
        private const val OWM_KEY = "fb59931eaffe800adb5c9e886c6481c9"
        private const val WEATHER_INTERVAL_MS = 45L * 60 * 1000
        private const val W_DEFAULT = 0.5f
        private const val W_EXPANDED = 0.7f

        // Acciones de iluminación del coche (cada fabricante usa las suyas).
        private val ILLUM_ACTIONS = arrayOf("com.carlauncher.ACTION_HEADLIGHTS")
        private const val NIGHT_BRIGHTNESS = 0.25f
    }

    private fun <T : View> v(id: Int): T = findViewById(id)

    private val rootView by lazy { v<View>(R.id.root) }
    private val topRow by lazy { v<View>(R.id.topRow) }
    private val mapCard by lazy { v<View>(R.id.mapCard) }
    private val musicCard by lazy { v<View>(R.id.musicCard) }
    private val infoCard by lazy { v<View>(R.id.infoCard) }
    private val dock by lazy { v<View>(R.id.dock) }
    private val speedBadge by lazy { v<View>(R.id.speedBadge) }
    private val map by lazy { v<MapView>(R.id.map) }
    private val ivArt by lazy { v<ImageView>(R.id.ivArt) }
    private val tvTitle by lazy { v<TextView>(R.id.tvTitle) }
    private val tvArtist by lazy { v<TextView>(R.id.tvArtist) }
    private val tvPos by lazy { v<TextView>(R.id.tvPos) }
    private val tvDur by lazy { v<TextView>(R.id.tvDur) }
    private val progress by lazy { v<ProgressBar>(R.id.progress) }
    private val btnPlay by lazy { v<ImageButton>(R.id.btnPlay) }
    private val btnPrev by lazy { v<ImageButton>(R.id.btnPrev) }
    private val btnNext by lazy { v<ImageButton>(R.id.btnNext) }
    private val tvSpeed by lazy { v<TextView>(R.id.tvSpeed) }
    private val tvTemp by lazy { v<TextView>(R.id.tvTemp) }
    private val tvWeatherIcon by lazy { v<TextView>(R.id.tvWeatherIcon) }
    private val tvWeatherDesc by lazy { v<TextView>(R.id.tvWeatherDesc) }
    private val tvWeatherSub by lazy { v<TextView>(R.id.tvWeatherSub) }
    private val clock by lazy { v<TextClock>(R.id.clock) }
    private val drawer by lazy { v<View>(R.id.drawer) }
    private val appGrid by lazy { v<GridView>(R.id.appGrid) }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var expanded = false
    private var themeIdx = 0
    private var nightManual: Boolean? = null
    private var nightByCar = false

    private var marker: Marker? = null
    private var lat = Double.NaN
    private var lon = Double.NaN
    private var firstFix = true

    private lateinit var lm: LocationManager
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerCn: ComponentName
    private var controller: MediaController? = null
    private var apps: List<AppItem> = emptyList()

    // ---------------- Ciclo de vida ----------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
            tileFileSystemCacheMaxBytes = 100L * 1024 * 1024
            cacheMapTileCount = 12
        }
        setContentView(R.layout.activity_main)

        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerCn = ComponentName(this, MediaListenerService::class.java)

        ivArt.clipToOutline = true
        setupMap()
        setupControls()
        setupDock()
        ensureLocationPermission()

        themeIdx = getSharedPreferences("prefs", MODE_PRIVATE).getInt("theme3", 0).coerceIn(0, THEMES.size - 1)
        applyTheme(themeIdx)
        applyNight()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        startLocation()
        refreshSessions()
        try { msm.addOnActiveSessionsChangedListener(sessionsListener, listenerCn) } catch (_: SecurityException) {}
        registerReceiver(illumReceiver, IntentFilter().apply { ILLUM_ACTIONS.forEach { addAction(it) } })
        main.post(weatherTask)
        main.post(progressTask)
        applyNight()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        try { lm.removeUpdates(locListener) } catch (_: SecurityException) {}
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        try { unregisterReceiver(illumReceiver) } catch (_: Exception) {}
        controller?.unregisterCallback(mediaCallback)
        controller = null
        main.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        map.onDetach()
        io.shutdownNow()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeDrawer() // botón Home: volver a la pantalla principal
    }

    @Deprecated("Launcher")
    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    // ---------------- Mapa ----------------
    private fun setupMap() {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.setUseDataConnection(true)
        map.isTilesScaledToDpi = false
        map.controller.setZoom(16.0)
        map.controller.setCenter(GeoPoint(19.4326, -99.1332))
        marker = Marker(map).apply {
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            setIcon(ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_marker))
            map.overlays.add(this)
        }
        mapCard.clipToOutline = true
        // Mapa oscuro permanente (tiles invertidos), acorde al diseño
        map.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)

        map.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean { toggleMap(); return true }
            override fun longPressHelper(p: GeoPoint?): Boolean = false
        }))
        marker?.setOnMarkerClickListener(Marker.OnMarkerClickListener { _, _ -> toggleMap(); true })

        v<View>(R.id.btnExpand).setOnClickListener { toggleMap() }
        v<View>(R.id.btnZoomIn).setOnClickListener { map.controller.zoomIn() }
        v<View>(R.id.btnZoomOut).setOnClickListener { map.controller.zoomOut() }
        v<View>(R.id.btnCenter).setOnClickListener { centerOnMe() }
    }

    private fun centerOnMe() {
        if (lat.isNaN()) Toast.makeText(this, "Sin señal GPS todavía", Toast.LENGTH_SHORT).show()
        else map.controller.animateTo(GeoPoint(lat, lon))
    }

    private fun toggleMap() = setExpanded(!expanded)

    private fun setExpanded(value: Boolean) {
        if (expanded == value) return
        expanded = value
        val mapLp = mapCard.layoutParams as LinearLayout.LayoutParams
        val musicLp = musicCard.layoutParams as LinearLayout.LayoutParams
        val to = if (expanded) W_EXPANDED else W_DEFAULT
        ValueAnimator.ofFloat(mapLp.weight, to).apply {
            duration = 250
            addUpdateListener {
                val w = it.animatedValue as Float
                mapLp.weight = w
                musicLp.weight = 1f - w
                topRow.requestLayout()
            }
            start()
        }
    }

    // ---------------- Música ----------------
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    private fun refreshSessions() {
        try {
            bind(msm.getActiveSessions(listenerCn))
        } catch (_: SecurityException) {
            tvTitle.text = "Sin acceso a multimedia"
            tvArtist.text = "Toca aquí para conceder acceso"
        }
    }

    private fun bind(list: List<MediaController>?) {
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (pick?.sessionToken == controller?.sessionToken) return
        controller?.unregisterCallback(mediaCallback)
        controller = pick
        pick?.registerCallback(mediaCallback)
        updateMeta(pick?.metadata)
        updateState(pick?.playbackState)
    }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMeta(metadata)
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateState(state)
        override fun onSessionDestroyed() { controller = null; refreshSessions() }
    }

    private fun updateMeta(m: MediaMetadata?) {
        tvTitle.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin reproducción"
        tvArtist.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (bmp != null) ivArt.setImageBitmap(bmp) else ivArt.setImageDrawable(null)
    }

    private fun updateState(s: PlaybackState?) {
        btnPlay.setImageResource(if (s?.state == PlaybackState.STATE_PLAYING) R.drawable.ic_pause_dark else R.drawable.ic_play_dark)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private val progressTask = object : Runnable {
        override fun run() {
            val c = controller
            val s = c?.playbackState
            val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (s != null && dur > 0) {
                var pos = s.position
                if (s.state == PlaybackState.STATE_PLAYING)
                    pos += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
                pos = pos.coerceIn(0, dur)
                progress.progress = (pos * 1000 / dur).toInt()
                tvPos.text = fmt(pos)
                tvDur.text = fmt(dur)
            } else {
                progress.progress = 0
                tvPos.text = "0:00"
                tvDur.text = "0:00"
            }
            main.postDelayed(this, 1000)
        }
    }

    private fun sendKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun setupControls() {
        btnPrev.setOnClickListener { controller?.transportControls?.skipToPrevious() ?: sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        btnNext.setOnClickListener { controller?.transportControls?.skipToNext() ?: sendKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        btnPlay.setOnClickListener {
            val c = controller
            if (c == null) { sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return@setOnClickListener }
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        val openAccess = View.OnClickListener {
            if (controller == null) safeStart(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        tvTitle.setOnClickListener(openAccess)
        tvArtist.setOnClickListener(openAccess)

        // Tarjeta de atajos
        v<View>(R.id.btnMic).setOnClickListener { safeStart(Intent(Intent.ACTION_VOICE_COMMAND)) }
        v<View>(R.id.btnHome).setOnClickListener { closeDrawer(); setExpanded(false) }
        v<View>(R.id.searchField).setOnClickListener { safeStart(Intent(Intent.ACTION_WEB_SEARCH)) }
        v<View>(R.id.btnTheme).setOnClickListener {
            themeIdx = (themeIdx + 1) % THEMES.size
            getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("theme3", themeIdx).apply()
            applyTheme(themeIdx)
            Toast.makeText(this, THEMES[themeIdx].name, Toast.LENGTH_SHORT).show()
        }
        // Pulsación larga en el hora: brillo nocturno auto -> noche -> día
        clock.setOnLongClickListener {
            nightManual = when (nightManual) { null -> true; true -> false; else -> null }
            applyNight()
            Toast.makeText(this, when (nightManual) { null -> "Noche: auto"; true -> "Noche: ON"; else -> "Noche: OFF" }, Toast.LENGTH_SHORT).show()
            true
        }
    }

    // ---------------- Barra de apps y cajón ----------------
    private fun setupDock() {
        v<View>(R.id.tileHome).setOnClickListener { closeDrawer(); setExpanded(false) }
        v<View>(R.id.tileMaps).setOnClickListener { closeDrawer(); toggleMap() }
        v<View>(R.id.tileMusic).setOnClickListener {
            val pkg = controller?.packageName
            val i = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
            if (i != null) safeStart(i) else Toast.makeText(this, "No hay reproductor activo", Toast.LENGTH_SHORT).show()
        }
        v<View>(R.id.tileApps).setOnClickListener { openDrawer() }
        v<View>(R.id.tileSettings).setOnClickListener { safeStart(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        v<View>(R.id.tilePhone).setOnClickListener { safeStart(Intent(Intent.ACTION_DIAL)) }
        v<View>(R.id.btnCloseDrawer).setOnClickListener { closeDrawer() }
        appGrid.setOnItemClickListener { _, _, pos, _ ->
            val ai = apps[pos].ri.activityInfo
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(ai.packageName, ai.name)
            closeDrawer()
            safeStart(i)
        }
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { Toast.makeText(this, "No disponible en esta unidad", Toast.LENGTH_SHORT).show() }
    }

    private fun openDrawer() {
        if (apps.isEmpty()) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            apps = packageManager.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(packageManager).toString(), it) }
                .sortedBy { it.label.lowercase() }
        }
        appGrid.adapter = AppAdapter(apps)
        drawer.visibility = View.VISIBLE
    }

    private fun closeDrawer() {
        if (drawer.visibility != View.VISIBLE) return
        drawer.visibility = View.GONE
        appGrid.adapter = null // libera los íconos
    }

    private inner class AppAdapter(val items: List<AppItem>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
            val item = items[position]
            row.findViewById<ImageView>(R.id.appIcon).setImageDrawable(item.ri.loadIcon(packageManager))
            row.findViewById<TextView>(R.id.appLabel).text = item.label
            return row
        }
    }

    // ---------------- GPS / Velocímetro ----------------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) Math.round(loc.speed * 3.6f) else 0
            tvSpeed.text = "$kmh"
            lat = loc.latitude; lon = loc.longitude
            val p = GeoPoint(lat, lon)
            marker?.position = p
            if (firstFix || (expanded && kmh > 5)) { map.controller.setCenter(p); firstFix = false }
            map.invalidate()
        }
        @Deprecated("") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    private fun ensureLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        startLocation()
    }

    private fun startLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener) } catch (_: Exception) {}
    }

    // ---------------- Clima (cada 45 min) ----------------
    private val weatherTask = object : Runnable {
        override fun run() {
            if (lat.isNaN()) { main.postDelayed(this, 30_000); return }
            val la = lat; val lo = lon
            io.execute {
                try {
                    val url = URL("https://api.openweathermap.org/data/2.5/weather?lat=$la&lon=$lo&units=metric&lang=es&appid=$OWM_KEY")
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    c.disconnect()
                    val j = JSONObject(body)
                    val mj = j.getJSONObject("main")
                    val t = Math.round(mj.getDouble("temp")).toInt()
                    val tMax = Math.round(mj.getDouble("temp_max")).toInt()
                    val tMin = Math.round(mj.getDouble("temp_min")).toInt()
                    val w = j.getJSONArray("weather").getJSONObject(0)
                    val id = w.getInt("id")
                    val desc = w.getString("description").replaceFirstChar { ch -> ch.uppercase() }
                    main.post {
                        tvTemp.text = "$t°"
                        tvWeatherIcon.text = emoji(id)
                        tvWeatherDesc.text = desc
                        tvWeatherSub.text = "Máx $tMax° · Mín $tMin°"
                    }
                } catch (_: Exception) { /* sin red: conservar último valor */ }
            }
            main.postDelayed(this, WEATHER_INTERVAL_MS)
        }
    }

    private fun emoji(id: Int) = when {
        id in 200..232 -> "⛈"; id in 300..321 -> "🌦"; id in 500..531 -> "🌧"
        id in 600..622 -> "❄"; id in 700..781 -> "🌫"; id == 800 -> "☀"; else -> "☁"
    }

    // ---------------- Temas ----------------
    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun rounded(color: Int, dp: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp * resources.displayMetrics.density
    }

    private fun meshDrawable(t: AppTheme): LayerDrawable {
        val d = resources.displayMetrics.density
        val r = 18f * d
        val base = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(t.m1, t.m2, t.m3)).apply { cornerRadius = r }
        fun blob(c: Int, cx: Float, cy: Float, rad: Float) = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            setGradientCenter(cx, cy)
            gradientRadius = rad
            colors = intArrayOf(withAlpha(c, 0xB0), withAlpha(c, 0))
            cornerRadius = r
        }
        return LayerDrawable(arrayOf(base, blob(t.blobB, 0.1f, 0.12f, 280f * d), blob(t.blobA, 0.92f, 0.88f, 280f * d)))
    }

    private fun applyTheme(i: Int) {
        val t = THEMES[i]
        val d = resources.displayMetrics.density
        rootView.setBackgroundColor(t.bg)
        mapCard.background = rounded(t.card, 18f)
        dock.background = rounded(t.card, 20f)
        musicCard.background = meshDrawable(t)
        infoCard.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(withAlpha(t.infoA, 0xF2), withAlpha(t.infoB, 0xF2))).apply { cornerRadius = 16f * d }
        speedBadge.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xF00A0E1C.toInt())
            setStroke((2 * d).toInt(), t.accent)
        }
        btnPlay.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.accent) }
        tvSpeed.setTextColor(t.accent)
        tvTitle.setTextColor(t.text)
        tvArtist.setTextColor(withAlpha(t.text, 0xD9))
        clock.setTextColor(t.text)
        tvTemp.setTextColor(t.text)
        progress.progressTintList = ColorStateList.valueOf(t.accent)
        progress.progressBackgroundTintList = ColorStateList.valueOf(withAlpha(t.text, 0x40))
        btnPrev.setColorFilter(t.text)
        btnNext.setColorFilter(t.text)
    }

    // ---------------- Modo noche (brillo) ----------------
    private val illumReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            nightByCar = i.getBooleanExtra("on", i.getIntExtra("state", 0) == 1)
            applyNight()
        }
    }

    private fun isNight(): Boolean {
        nightManual?.let { return it }
        if (nightByCar) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 19 || h < 6
    }

    private fun applyNight() {
        val lp = window.attributes
        lp.screenBrightness = if (isNight()) NIGHT_BRIGHTNESS else android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }
}
