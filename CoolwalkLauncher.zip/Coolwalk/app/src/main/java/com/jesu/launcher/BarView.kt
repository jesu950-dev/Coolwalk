package com.jesu.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Barra de progreso de la canción; tocar adelanta o atrasa. */
class BarView(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var trackColor = 0x55FFFFFF
    var fillColor = 0xFFFFFFFF.toInt()
    var onSeek: ((Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val th = h * 0.28f
        val cy = h / 2f
        val knob = h * 0.42f
        p.color = trackColor
        r.set(knob, cy - th / 2f, w - knob, cy + th / 2f)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        p.color = fillColor
        val x = knob + (w - 2 * knob) * frac
        r.set(knob, cy - th / 2f, x, cy + th / 2f)
        c.drawRoundRect(r, th / 2f, th / 2f, p)
        c.drawCircle(x, cy, knob, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP && width > 0) {
            onSeek?.invoke((e.x / width).coerceIn(0f, 1f))
        }
        return true
    }
}
