# Coolwalk Launcher (estéreo XY Auto, 1024x600)

## Opción A: compilar sin instalar nada (GitHub)
1. Creá un repositorio en github.com (privado o público).
2. Subí TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
3. Entrá a la pestaña **Actions** → "Compilar APK" → se ejecuta sola (si no, botón *Run workflow*).
4. Cuando termine (unos 5 min), abrí la ejecución y bajá **CoolwalkLauncher-APK** (adentro está app-debug.apk).

## Opción B: Android Studio
1. File → Open → elegí esta carpeta y esperá que sincronice.
2. Build → Build Bundle(s)/APK(s) → Build APK(s).
3. La APK queda en app/build/outputs/apk/debug/app-debug.apk

## Instalar en el estéreo por WiFi
1. El repositorio tiene que ser PÚBLICO. Al terminar la compilación, el link de descarga directo es:
   https://github.com/TU_USUARIO/TU_REPO/releases/download/ultima/app-debug.apk
   Abrilo en el navegador del estéreo, descargá e instalá (permití "orígenes desconocidos").
2. Apretá Home y elegí **Coolwalk Launcher** → "Siempre".
3. Aceptá los permisos de ubicación y audio.
4. Activá el acceso a notificaciones para Coolwalk Launcher (toca la tarjeta de música) para ver YouTube Music.

## Uso
- Mantené apretado un ícono de la barra (mapas, música, Android Auto, teléfono) para cambiar la app.
- Engranaje: tema (automático/claro/oscuro), estilo de luces, direcciones de Casa y Trabajo.
- Luces: solo se mueven con música.
