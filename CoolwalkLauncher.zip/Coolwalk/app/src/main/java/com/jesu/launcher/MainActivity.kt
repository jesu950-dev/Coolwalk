package com.jesu.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.audiofx.Visualizer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.preference.PreferenceManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.min

class MainActivity : Activity(), LocationListener {

    // ---------- escala: el diseño está pensado en 1024x600 y se estira a la pantalla real ----------
    private var sx = 1f
    private var sy = 1f
    private var su = 1f
    private fun X(v: Number) = (v.toFloat() * sx).toInt()
    private fun Y(v: Number) = (v.toFloat() * sy).toInt()
    private fun U(v: Number) = (v.toFloat() * su).toInt()
    private fun lp(x: Number, y: Number, w: Number, h: Number): FrameLayout.LayoutParams {
        val p = FrameLayout.LayoutParams(X(w), Y(h))
        p.leftMargin = X(x)
        p.topMargin = Y(y)
        return p
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("ajustes", MODE_PRIVATE) }

    // vistas
    private lateinit var root: FrameLayout
    private lateinit var glows: List<View>
    private lateinit var spectrum: SpectrumView
    private lateinit var mapCard: FrameLayout
    private lateinit var map: MapView
    private lateinit var myLoc: MyLocationNewOverlay
    private lateinit var mapTint: View
    private lateinit var mapBorder: View
    private lateinit var speedRing: SpeedRing
    private lateinit var btnFollow: ImageView
    private lateinit var btnZoomIn: TextView
    private lateinit var btnZoomOut: TextView
    private lateinit var routeChip: TextView
    private lateinit var handle: View
    private lateinit var bottomPanel: FrameLayout
    private lateinit var btnMic: ImageView
    private lateinit var btnCasa: ImageView
    private lateinit var btnTrabajo: ImageView
    private lateinit var search: EditText
    private lateinit var dateClock: TextView
    private lateinit var divider: View
    private lateinit var wIcon: ImageView
    private lateinit var wText1: TextView
    private lateinit var wText2: TextView
    private lateinit var tempTv: TextView
    private lateinit var weatherRow: List<View>
    private lateinit var musicCard: FrameLayout
    private lateinit var badge: ImageView
    private lateinit var art: ImageView
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var bar: BarView
    private lateinit var tPos: TextView
    private lateinit var tDur: TextView
    private lateinit var btnPrev: ImageView
    private lateinit var btnPlay: ImageView
    private lateinit var btnNext: ImageView
    private lateinit var btnOpen: TextView
    private lateinit var dock: FrameLayout
    private lateinit var clockTv: TextView
    private lateinit var dockDate: TextView
    private val dockSlots = ArrayList<ImageView>()
    private val tintViews = ArrayList<ImageView>()

    // estado
    private var routeLine: Polyline? = null
    private var controller: MediaController? = null
    private var sessions: List<MediaController> = emptyList()
    private var noAccess = false
    private var visualizer: Visualizer? = null
    private var panelOpen = true
    private var sunrise = -1
    private var sunset = -1
    private var lastWeather = 0L
    private var palette: Palette = Themes.NIGHT
    private var lastTileDark: Boolean? = null
    private val darkTiles = XYTileSource("CartoDark", 0, 19, 256, ".png", arrayOf(
        "https://a.basemaps.cartocdn.com/dark_all/", "https://b.basemaps.cartocdn.com/dark_all/", "https://c.basemaps.cartocdn.com/dark_all/"))
    private val lightTiles = XYTileSource("CartoLight", 0, 19, 256, ".png", arrayOf(
        "https://a.basemaps.cartocdn.com/light_all/", "https://b.basemaps.cartocdn.com/light_all/", "https://c.basemaps.cartocdn.com/light_all/"))
    private var gpsOffset: Long? = null // diferencia entre la hora del GPS y la del sistema
    private val clocks = ArrayList<Pair<TextView, String>>()

    // ---------- accesos de la barra de abajo ----------
    private class SlotDef(
        val key: String, val words: Array<String>, val fallback: Int,
        val color: Int, val custom: Boolean
    )

    private val slotDefs = listOf(
        SlotDef("home", arrayOf(), R.drawable.ic_home, 0xFF2878FF.toInt(), false),
        SlotDef("maps", arrayOf("waze", "maps", "mapas"), R.drawable.ic_map, 0xFFE5484D.toInt(), true),
        SlotDef("music", arrayOf("youtube music", "music", "música"), R.drawable.ic_music, 0xFFFF2A44.toInt(), true),
        SlotDef("apps", arrayOf(), R.drawable.ic_apps, 0xFF3C96FF.toInt(), false),
        SlotDef("settings", arrayOf(), R.drawable.ic_settings, 0xFF7E8396.toInt(), false),
        SlotDef("car", arrayOf("zlink", "carplay", "android auto"), R.drawable.ic_car, 0xFF323850.toInt(), true),
        SlotDef("phone", arrayOf("bt phone", "phone", "teléfono", "dialer"), R.drawable.ic_phone, 0xFF3CDC6E.toInt(), true)
    )

    companion object {
        const val YTM = "com.google.android.apps.youtube.music"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dm = resources.displayMetrics
        sx = dm.widthPixels / 1024f
        sy = dm.heightPixels / 600f
        su = min(sx, sy)
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this))
        Configuration.getInstance().userAgentValue = packageName

        buildUi()
        applyTheme()
        refreshDockIcons()
        setupMedia()
        requestPerms()
        handler.post(minuteTick)
        handler.post(ticker)
    }

    // =====================================================================
    //  Construcción de la pantalla
    // =====================================================================
    private fun tv(size: Float, bold: Boolean = false, gravity: Int = Gravity.CENTER_VERTICAL): TextView {
        val t = TextView(this)
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * su)
        t.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        t.gravity = gravity
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        t.includeFontPadding = false
        return t
    }

    private fun icon(res: Int, pad: Float = 0f): ImageView {
        val i = ImageView(this)
        i.setImageResource(res)
        i.scaleType = ImageView.ScaleType.FIT_CENTER
        val p = U(pad)
        i.setPadding(p, p, p, p)
        tintViews.add(i)
        return i
    }

    private fun clockView(format: String, size: Float, bold: Boolean): TextView {
        val c = TextView(this)
        c.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * su)
        c.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.gravity = Gravity.CENTER
        c.includeFontPadding = false
        clocks.add(Pair(c, format))
        return c
    }

    // muestra la hora real: la del GPS si ya hay señal, y si no la del sistema
    private fun tickClocks() {
        val id = prefs.getString("tz", null)
        val tz = if (id != null) TimeZone.getTimeZone(id) else TimeZone.getDefault()
        val d = java.util.Date(System.currentTimeMillis() + (gpsOffset ?: 0L))
        for ((v, f) in clocks) {
            val sdf = java.text.SimpleDateFormat(f, java.util.Locale("es", "AR"))
            sdf.timeZone = tz
            v.text = sdf.format(d)
        }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        setContentView(root)

        val g1 = View(this); root.addView(g1, lp(560, -160, 640, 640))
        val g2 = View(this); root.addView(g2, lp(520, 260, 700, 520))
        val g3 = View(this); root.addView(g3, lp(-200, 260, 700, 520))
        val g4 = View(this); root.addView(g4, lp(-160, -160, 560, 420))
        glows = listOf(g1, g2, g3, g4)

        spectrum = SpectrumView(this, null)
        root.addView(spectrum, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ----- tarjeta del mapa -----
        mapCard = FrameLayout(this)
        root.addView(mapCard, lp(12, 12, 548, 466))
        mapCard.clipToOutline = true
        mapCard.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, U(24).toFloat())
            }
        }
        val match = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        map = MapView(this)
        mapCard.addView(map, match)
        setupMap()
        mapTint = View(this)
        mapCard.addView(mapTint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        speedRing = SpeedRing(this)
        mapCard.addView(speedRing, lp(14, 14, 90, 90))
        btnFollow = icon(R.drawable.ic_nav, 16f)
        mapCard.addView(btnFollow, lp(14, 114, 60, 60))
        btnFollow.setOnClickListener { followMe() }

        btnZoomIn = tv(30f, true, Gravity.CENTER); btnZoomIn.text = "+"
        btnZoomOut = tv(30f, true, Gravity.CENTER); btnZoomOut.text = "−"
        mapCard.addView(btnZoomIn, lp(488, 14, 48, 48))
        mapCard.addView(btnZoomOut, lp(488, 70, 48, 48))
        btnZoomIn.setOnClickListener { map.controller.zoomIn() }
        btnZoomOut.setOnClickListener { map.controller.zoomOut() }

        routeChip = tv(17f, true, Gravity.CENTER)
        routeChip.visibility = View.GONE
        mapCard.addView(routeChip, lp(140, 14, 270, 44))
        routeChip.setOnClickListener { clearRoute() }

        handle = View(this)
        mapCard.addView(handle, lp(244, 296, 60, 18))
        handle.setOnClickListener { togglePanel() }

        // ----- panel de abajo (botones, búsqueda, fecha y clima) -----
        bottomPanel = FrameLayout(this)
        mapCard.addView(bottomPanel, lp(12, 314, 524, 140))
        btnMic = icon(R.drawable.ic_mic, 13f); bottomPanel.addView(btnMic, lp(8, 14, 52, 52))
        btnCasa = icon(R.drawable.ic_home, 13f); bottomPanel.addView(btnCasa, lp(68, 14, 52, 52))
        btnTrabajo = icon(R.drawable.ic_work, 13f); bottomPanel.addView(btnTrabajo, lp(128, 14, 52, 52))
        search = EditText(this)
        search.hint = "Buscar destino"
        search.setSingleLine(true)
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.setTextSize(TypedValue.COMPLEX_UNIT_PX, 17f * su)
        search.setPadding(U(20), 0, U(20), 0)
        bottomPanel.addView(search, lp(190, 14, 320, 52))
        search.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard(); routeTo(v.text.toString(), false); true
            } else false
        }
        btnMic.setOnClickListener { listen() }
        savedPlace(btnCasa, "casa", "Casa")
        savedPlace(btnTrabajo, "trabajo", "Trabajo")

        dateClock = clockView("EEE d MMM", 17f, true)
        bottomPanel.addView(dateClock, lp(14, 84, 120, 44))
        divider = View(this)
        bottomPanel.addView(divider, lp(140, 90, 2, 36))
        wIcon = icon(R.drawable.ic_cloud, 4f)
        bottomPanel.addView(wIcon, lp(158, 90, 40, 40))
        wText1 = tv(16f, true)
        wText2 = tv(12f)
        bottomPanel.addView(wText1, lp(208, 88, 200, 22))
        bottomPanel.addView(wText2, lp(208, 112, 200, 18))
        tempTv = tv(34f, false, Gravity.CENTER_VERTICAL or Gravity.END)
        bottomPanel.addView(tempTv, lp(390, 86, 120, 48))
        wText1.text = "Clima"; wText2.text = "Esperando GPS…"; tempTv.text = "--°"
        weatherRow = listOf(dateClock, divider, wIcon, wText1, wText2, tempTv)

        mapBorder = View(this)
        mapCard.addView(mapBorder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ----- tarjeta de música -----
        musicCard = FrameLayout(this)
        root.addView(musicCard, lp(572, 12, 440, 466))
        badge = ImageView(this)
        badge.scaleType = ImageView.ScaleType.FIT_CENTER
        musicCard.addView(badge, lp(380, 12, 44, 44))
        art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.clipToOutline = true
        art.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, U(14).toFloat())
            }
        }
        musicCard.addView(art, lp(125, 34, 190, 190))
        titleTv = tv(26f, true, Gravity.CENTER)
        artistTv = tv(15f, false, Gravity.CENTER)
        musicCard.addView(titleTv, lp(20, 236, 400, 40))
        musicCard.addView(artistTv, lp(20, 278, 400, 26))
        bar = BarView(this)
        musicCard.addView(bar, lp(24, 314, 392, 24))
        tPos = tv(11f, false, Gravity.START or Gravity.CENTER_VERTICAL)
        tDur = tv(11f, false, Gravity.END or Gravity.CENTER_VERTICAL)
        musicCard.addView(tPos, lp(24, 340, 100, 18))
        musicCard.addView(tDur, lp(316, 340, 100, 18))
        btnPrev = icon(R.drawable.ic_prev, 14f); musicCard.addView(btnPrev, lp(96, 370, 60, 60))
        btnPlay = icon(R.drawable.ic_play, 8f); musicCard.addView(btnPlay, lp(186, 366, 68, 68))
        btnNext = icon(R.drawable.ic_next, 14f); musicCard.addView(btnNext, lp(284, 370, 60, 60))
        btnOpen = tv(15f, true, Gravity.CENTER)
        btnOpen.text = "Abrir YouTube Music"
        musicCard.addView(btnOpen, lp(110, 418, 220, 40))
        setupMediaButtons()

        // ----- barra de abajo -----
        dock = FrameLayout(this)
        root.addView(dock, lp(12, 492, 1000, 96))
        for ((i, def) in slotDefs.withIndex()) {
            val v = ImageView(this)
            v.scaleType = ImageView.ScaleType.FIT_CENTER
            dock.addView(v, lp(66 + 110 * i, 16, 64, 64))
            dockSlots.add(v)
            v.setOnClickListener { onSlotClick(def) }
            if (def.custom) v.setOnLongClickListener { chooseSlotApp(def); true }
        }
        clockTv = clockView("HH:mm", 24f, true)
        dock.addView(clockTv, lp(818, 18, 150, 36))
        dockDate = clockView("EEE d MMM", 13f, false)
        dock.addView(dockDate, lp(818, 56, 150, 22))

        // luces: estilo guardado (por defecto apagadas)
        val st = prefs.getInt("luces", SpectrumView.NAMES.size - 1).coerceIn(0, SpectrumView.NAMES.size - 1)
        spectrum.applyStyle(st)
        root.isFocusableInTouchMode = true
        root.requestFocus()
        applyTz()
    }

    // =====================================================================
    //  Teclado y hora
    // =====================================================================
    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(search.windowToken, 0)
        } catch (e: Exception) { }
        search.clearFocus()
        root.requestFocus()
    }

    // tocar en cualquier lugar fuera del buscador cierra el teclado
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN && search.hasFocus()) {
            val r = Rect()
            search.getGlobalVisibleRect(r)
            if (!r.contains(ev.rawX.toInt(), ev.rawY.toInt())) hideKeyboard()
        }
        return super.dispatchTouchEvent(ev)
    }

    private val tzIds = arrayOf(null, "America/Argentina/Buenos_Aires", "America/Santiago", "America/Lima", "America/Mexico_City", "Europe/Madrid")
    private val tzNames = arrayOf(
        "Automática (la del equipo)", "Argentina / Uruguay (GMT-3)", "Chile",
        "Perú / Colombia / Ecuador (GMT-5)", "México (centro)", "España (Madrid)"
    )

    private fun applyTz() {
        val id = prefs.getString("tz", null)
        tickClocks()
    }

    // =====================================================================
    //  Tema noche / día
    // =====================================================================
    private fun shape(fill: Int, stroke: Int, radius: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = radius
        g.setStroke(maxOf(1, U(2)), stroke)
        return g
    }

    private fun glowDrawable(color: Int, sizePx: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.gradientType = GradientDrawable.RADIAL_GRADIENT
        g.gradientRadius = sizePx / 2f
        g.setColors(intArrayOf(color, color and 0x00FFFFFF))
        return g
    }

    private fun autoIsDark(): Boolean {
        val id = prefs.getString("tz", null)
        val cal = if (id != null) Calendar.getInstance(TimeZone.getTimeZone(id)) else Calendar.getInstance()
        cal.timeInMillis = System.currentTimeMillis() + (gpsOffset ?: 0L)
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (sunrise >= 0 && sunset >= 0) now < sunrise || now >= sunset
        else now < 7 * 60 || now >= 19 * 60
    }

    private fun applyTheme() {
        val mode = prefs.getInt("tema", 0) // 0 auto, 1 claro, 2 oscuro
        val dark = when (mode) { 1 -> false; 2 -> true; else -> autoIsDark() }
        val p = if (dark) Themes.night(prefs.getInt("colores", 0)) else Themes.DAY
        palette = p
        val rad = U(22).toFloat()
        val pill = U(60).toFloat()

        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.bg1, p.bg2, p.bg3))
        val gc = listOf(p.glowA, p.glowB, p.glowC, p.glowD)
        val gs = listOf(640, 700, 700, 560)
        for (i in glows.indices) glows[i].background = glowDrawable(gc[i], X(gs[i]))

        map.overlayManager.tilesOverlay.setColorFilter(null)
        if (lastTileDark != dark) {
            lastTileDark = dark
            map.setTileSource(if (dark) darkTiles else lightTiles)
        }
        map.invalidate()
        mapTint.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, if (dark) 0x40AA3CF0 else 0x40FF8AC8)
        )
        mapBorder.background = shape(Color.TRANSPARENT, if (dark) 0xFF9687FF.toInt() else 0xFFFFFFFF.toInt(), U(24).toFloat())

        speedRing.bgColor = p.glass
        speedRing.trackColor = if (dark) 0xFF3E4469.toInt() else 0xFFC9CFE8.toInt()
        speedRing.fillColor = p.accent
        speedRing.textColor = p.text
        speedRing.softColor = p.soft
        speedRing.invalidate()

        for (b in listOf(btnFollow)) b.background = shape(p.glass, p.stroke, pill)
        for (b in listOf(btnZoomIn, btnZoomOut)) {
            b.background = shape(p.glass, p.stroke, U(16).toFloat()); b.setTextColor(p.text)
        }
        routeChip.background = shape(p.glass, p.stroke, pill); routeChip.setTextColor(p.text)
        handle.background = android.graphics.drawable.InsetDrawable(shape(0xB3FFFFFF.toInt(), 0x00000000, U(3).toFloat()), 0, U(6), 0, U(6))

        bottomPanel.background = shape(p.panel, p.stroke, rad)
        for (b in listOf(btnMic, btnCasa, btnTrabajo)) b.background = shape(p.button, p.stroke, pill)
        search.background = shape(p.button, p.stroke, pill)
        search.setTextColor(p.text)
        search.setHintTextColor(p.soft)
        dateClock.setTextColor(p.text)
        divider.setBackgroundColor(p.stroke)
        wText1.setTextColor(p.text)
        wText2.setTextColor(p.soft)
        tempTv.setTextColor(p.text)

        musicCard.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.musicA, p.musicB)).also {
            it.cornerRadius = U(26).toFloat(); it.setStroke(maxOf(1, U(2)), p.stroke)
        }
        titleTv.setTextColor(p.text)
        artistTv.setTextColor(p.soft)
        tPos.setTextColor(p.soft)
        tDur.setTextColor(p.soft)
        bar.trackColor = if (dark) 0x55FFFFFF else 0x553B4070
        bar.fillColor = p.text
        bar.invalidate()
        btnOpen.setTextColor(p.text)
        btnOpen.background = shape(p.button, p.stroke, pill)

        dock.background = shape(p.dock, p.stroke, U(26).toFloat())
        clockTv.setTextColor(p.text)
        dockDate.setTextColor(p.soft)

        for (v in tintViews) v.setColorFilter(p.text)
    }

    private val minuteTick = object : Runnable {
        override fun run() {
            if (prefs.getInt("tema", 0) == 0) {
                val dark = autoIsDark()
                if (dark != palette.dark) applyTheme()
            }
            handler.postDelayed(this, 60000L)
        }
    }

    // =====================================================================
    //  Mapa, ruta y buscador
    // =====================================================================
    private fun setupMap() {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.controller.setZoom(16.0)
        map.controller.setCenter(GeoPoint(-34.6037, -58.3816))
        myLoc = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        myLoc.enableMyLocation()
        myLoc.enableFollowLocation()
        map.overlays.add(myLoc)
    }

    private fun followMe() {
        myLoc.enableFollowLocation()
        myLoc.myLocation?.let { map.controller.animateTo(it) }
    }

    private fun togglePanel() {
        panelOpen = !panelOpen
        for (v in weatherRow) v.visibility = if (panelOpen) View.VISIBLE else View.GONE
        val h = if (panelOpen) 140 else 80
        val p = lp(12, 454 - h, 524, h)
        bottomPanel.layoutParams = p
        handle.layoutParams = lp(244, 454 - h - 18, 60, 18)
    }

    private fun savedPlace(v: ImageView, key: String, label: String) {
        val sp = getSharedPreferences("lugares", MODE_PRIVATE)
        v.setOnClickListener {
            val addr = sp.getString(key, null)
            if (addr == null) askAddress(key, label) else routeTo(addr, false)
        }
        v.setOnLongClickListener { askAddress(key, label); true }
    }

    private fun askAddress(key: String, label: String) {
        val sp = getSharedPreferences("lugares", MODE_PRIVATE)
        val input = EditText(this)
        input.setText(sp.getString(key, ""))
        AlertDialog.Builder(this)
            .setTitle("Dirección de $label")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ -> sp.edit().putString(key, input.text.toString()).apply() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun listen() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "¿A dónde vamos?")
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            Toast.makeText(this, "Este equipo no tiene reconocimiento de voz; escribí el destino", Toast.LENGTH_LONG).show()
            search.requestFocus()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val q = r?.firstOrNull()
            if (!q.isNullOrBlank()) { search.setText(q); routeTo(q, false) }
        }
    }

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "CoolwalkLauncher/1.0")
        c.connectTimeout = 10000
        c.readTimeout = 15000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun routeTo(query: String, nearby: Boolean) {
        if (query.isBlank()) return
        routeChip.visibility = View.VISIBLE
        routeChip.text = "Buscando…"
        val here = myLoc.myLocation
        Thread {
            try {
                var url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + URLEncoder.encode(query, "UTF-8")
                if (nearby && here != null) {
                    val d = 0.08
                    url += "&bounded=1&viewbox=${here.longitude - d},${here.latitude + d},${here.longitude + d},${here.latitude - d}"
                }
                val arr = JSONArray(http(url))
                if (arr.length() == 0) {
                    runOnUiThread { routeChip.text = "No encontré ese lugar" }
                    return@Thread
                }
                val dest = arr.getJSONObject(0)
                val lat = dest.getString("lat").toDouble()
                val lon = dest.getString("lon").toDouble()
                val start = here ?: GeoPoint(map.mapCenter.latitude, map.mapCenter.longitude)
                val rUrl = "https://router.project-osrm.org/route/v1/driving/${start.longitude},${start.latitude};$lon,$lat?overview=full&geometries=geojson"
                val r: JSONObject = JSONObject(http(rUrl)).getJSONArray("routes").getJSONObject(0)
                val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
                val pts = ArrayList<GeoPoint>()
                for (i in 0 until coords.length()) {
                    val c = coords.getJSONArray(i)
                    pts.add(GeoPoint(c.getDouble(1), c.getDouble(0)))
                }
                val mins = Math.round(r.getDouble("duration") / 60.0)
                val km = r.getDouble("distance") / 1000.0
                runOnUiThread {
                    routeLine?.let { map.overlays.remove(it) }
                    val line = Polyline(map)
                    line.setPoints(pts)
                    line.outlinePaint.color = Color.parseColor("#46AFFF")
                    line.outlinePaint.strokeWidth = 16f
                    map.overlays.add(0, line)
                    routeLine = line
                    myLoc.disableFollowLocation()
                    map.zoomToBoundingBox(line.bounds, true, 80)
                    routeChip.text = "$mins min · ${"%.1f".format(km)} km  ✕"
                    map.invalidate()
                }
            } catch (e: Exception) {
                runOnUiThread { routeChip.text = "Sin conexión" }
            }
        }.start()
    }

    private fun clearRoute() {
        routeLine?.let { map.overlays.remove(it) }
        routeLine = null
        routeChip.visibility = View.GONE
        myLoc.enableFollowLocation()
        map.invalidate()
    }

    // =====================================================================
    //  Barra de abajo
    // =====================================================================
    private fun findApp(words: Array<String>): ResolveInfo? {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        for (w in words) {
            val hit = apps.firstOrNull {
                it.loadLabel(pm).toString().contains(w, true) || it.activityInfo.packageName.contains(w, true)
            }
            if (hit != null) return hit
        }
        return null
    }

    private fun resolvePkg(def: SlotDef): String? {
        prefs.getString("slot_" + def.key, null)?.let { if (packageManager.getLaunchIntentForPackage(it) != null) return it }
        if (def.key == "music" && packageManager.getLaunchIntentForPackage(YTM) != null) return YTM
        return findApp(def.words)?.activityInfo?.packageName
    }

    private fun refreshDockIcons() {
        for ((i, def) in slotDefs.withIndex()) {
            val v = dockSlots[i]
            val pkg = if (def.custom) resolvePkg(def) else null
            if (pkg != null) {
                v.setPadding(0, 0, 0, 0)
                v.background = null
                v.setImageDrawable(packageManager.getApplicationIcon(pkg))
            } else {
                val pd = U(15)
                v.setPadding(pd, pd, pd, pd)
                v.background = shape(def.color, 0x00000000, U(16).toFloat())
                v.setImageResource(def.fallback)
            }
        }
    }

    private fun onSlotClick(def: SlotDef) {
        when (def.key) {
            "home" -> { followMe(); clearRoute() }
            "apps" -> showAppList("Aplicaciones") { launchPkg(it) }
            "settings" -> showSettings()
            else -> {
                val pkg = resolvePkg(def)
                if (pkg != null) launchPkg(pkg)
                else Toast.makeText(this, "Mantené apretado para elegir la app", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun chooseSlotApp(def: SlotDef) {
        showAppList("Elegí la app para este acceso") { pkg ->
            prefs.edit().putString("slot_" + def.key, pkg).apply()
            refreshDockIcons()
        }
    }

    private fun launchPkg(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun showAppList(title: String, onPick: (String) -> Unit) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val adapter = object : ArrayAdapter<ResolveInfo>(this, android.R.layout.simple_list_item_1, apps) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val t = super.getView(position, convertView, parent) as TextView
                val ri = getItem(position)!!
                t.text = ri.loadLabel(pm)
                val d = ri.loadIcon(pm)
                val s = U(36)
                d.setBounds(0, 0, s, s)
                t.setCompoundDrawables(d, null, null, null)
                t.compoundDrawablePadding = U(12)
                return t
            }
        }
        val lv = ListView(this)
        lv.adapter = adapter
        val dlg = AlertDialog.Builder(this).setTitle(title).setView(lv).setNegativeButton("Cerrar", null).create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            onPick(apps[pos].activityInfo.packageName)
            dlg.dismiss()
        }
        dlg.show()
    }

    // =====================================================================
    //  Ajustes
    // =====================================================================
    private fun showSettings() {
        val temas = arrayOf("Automático", "Claro", "Oscuro")
        val tzNow = tzIds.indexOf(prefs.getString("tz", null)).coerceAtLeast(0)
        val colNow = prefs.getInt("colores", 0).coerceIn(0, Themes.NAMES.size - 1)
        val items = arrayOf(
            "Tema: " + temas[prefs.getInt("tema", 0)],
            "Colores (modo noche): " + Themes.NAMES[colNow],
            "Luces: " + SpectrumView.NAMES[spectrum.style],
            "Zona horaria del reloj: " + tzNames[tzNow],
            "Dirección de Casa",
            "Dirección de Trabajo",
            "Fecha y hora de Android",
            "Ajustes de Android",
            "Restablecer accesos de la barra",
            "Créditos del mapa"
        )
        AlertDialog.Builder(this).setTitle("Ajustes").setItems(items) { _, which ->
            when (which) {
                0 -> AlertDialog.Builder(this).setTitle("Tema")
                    .setSingleChoiceItems(temas, prefs.getInt("tema", 0)) { d, i ->
                        prefs.edit().putInt("tema", i).apply(); applyTheme(); d.dismiss()
                    }.show()
                1 -> AlertDialog.Builder(this).setTitle("Colores del modo noche")
                    .setSingleChoiceItems(Themes.NAMES, colNow) { d, i ->
                        prefs.edit().putInt("colores", i).apply(); applyTheme(); d.dismiss()
                    }.show()
                2 -> AlertDialog.Builder(this).setTitle("Luces (solo con música)")
                    .setSingleChoiceItems(SpectrumView.NAMES, spectrum.style) { d, i ->
                        prefs.edit().putInt("luces", i).apply(); spectrum.applyStyle(i); d.dismiss()
                    }.show()
                3 -> AlertDialog.Builder(this).setTitle("Zona horaria del reloj")
                    .setSingleChoiceItems(tzNames, tzNow) { d, i ->
                        val e = prefs.edit()
                        if (tzIds[i] == null) e.remove("tz") else e.putString("tz", tzIds[i])
                        e.apply(); applyTz(); applyTheme(); d.dismiss()
                    }.show()
                4 -> askAddress("casa", "Casa")
                5 -> askAddress("trabajo", "Trabajo")
                6 -> openAndroidSettings(Settings.ACTION_DATE_SETTINGS)
                7 -> openAndroidSettings(Settings.ACTION_SETTINGS)
                8 -> {
                    val e = prefs.edit()
                    for (d in slotDefs) e.remove("slot_" + d.key)
                    e.apply(); refreshDockIcons()
                }
                9 -> AlertDialog.Builder(this).setTitle("Créditos del mapa")
                    .setMessage("Datos del mapa © colaboradores de OpenStreetMap.\nEstilo de mapa © CARTO.\nRutas: OSRM. Clima: Open-Meteo.")
                    .setPositiveButton("Cerrar", null).show()
            }
        }.setNegativeButton("Cerrar", null).show()
    }

    private fun openAndroidSettings(action: String) {
        try { startActivity(Intent(action)) }
        catch (e: Exception) { Toast.makeText(this, "Este equipo no deja abrir esa pantalla desde acá", Toast.LENGTH_LONG).show() }
    }

    // =====================================================================
    //  Música (YouTube Music, Spotify o cualquier app con sesión de medios)
    // =====================================================================
    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = refreshMedia()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refreshMedia()
    }

    private val ticker = object : Runnable {
        override fun run() { tickClocks(); updateProgress(); handler.postDelayed(this, 500) }
    }

    private fun setupMediaButtons() {
        btnPrev.setOnClickListener { controller?.transportControls?.skipToPrevious() }
        btnNext.setOnClickListener { controller?.transportControls?.skipToNext() }
        btnPlay.setOnClickListener {
            val c = controller
            when {
                c == null -> openMusicApp()
                c.playbackState?.state == PlaybackState.STATE_PLAYING -> c.transportControls.pause()
                else -> c.transportControls.play()
            }
        }
        btnOpen.setOnClickListener { openMusicApp() }
        val openSource = View.OnClickListener {
            val pkg = controller?.packageName
            if (pkg != null) launchPkg(pkg)
            else if (noAccess) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            else openMusicApp()
        }
        art.setOnClickListener(openSource)
        titleTv.setOnClickListener(openSource)
        artistTv.setOnClickListener(openSource)
        badge.setOnClickListener {
            if (sessions.size > 1) select(sessions[(sessions.indexOf(controller) + 1) % sessions.size])
            else openMusicApp()
        }
        bar.onSeek = { f ->
            val dur = controller?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (dur > 0) controller?.transportControls?.seekTo((f * dur).toLong())
        }
    }

    private fun openMusicApp() {
        val def = slotDefs.first { it.key == "music" }
        val pkg = resolvePkg(def)
        if (pkg != null) launchPkg(pkg)
        else Toast.makeText(this, "No encontré YouTube Music; elegila en la barra (mantené apretado)", Toast.LENGTH_LONG).show()
    }

    private fun setupMedia() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, MediaListener::class.java)
            msm.addOnActiveSessionsChangedListener({ list -> bindSessions(list) }, cn)
            bindSessions(msm.getActiveSessions(cn))
            noAccess = false
        } catch (e: SecurityException) {
            noAccess = true
            titleTv.text = "Activá el acceso a la música"
            artistTv.text = "Tocá acá y habilitá Coolwalk Launcher"
        }
        refreshMedia()
    }

    private fun bindSessions(list: List<MediaController>?) {
        sessions = list ?: emptyList()
        val keep = sessions.firstOrNull { it.sessionToken == controller?.sessionToken }
        fun hasTitle(c: MediaController) = !c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).isNullOrBlank()
        val pick = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING && hasTitle(it) }
            ?: keep?.takeIf { hasTitle(it) }
            ?: sessions.firstOrNull { hasTitle(it) }
        select(pick)
    }

    private fun select(c: MediaController?) {
        controller?.unregisterCallback(mediaCb)
        controller = c
        c?.registerCallback(mediaCb, handler)
        refreshMedia()
    }

    private fun refreshMedia() {
        runOnUiThread {
            val c = controller
            if (c == null) {
                if (!noAccess) { titleTv.text = "Nada reproduciéndose"; artistTv.text = "Tocá ▶ para abrir YouTube Music" }
                art.setImageDrawable(null)
                art.background = shape(0x33FFFFFF, 0x00000000, U(14).toFloat())
                val ytm = try { packageManager.getApplicationIcon(YTM) } catch (e: Exception) { null }
                badge.setImageDrawable(ytm)
                btnPlay.setImageResource(R.drawable.ic_play)
                spectrum.playing = false
                bar.frac = 0f; tPos.text = ""; tDur.text = ""
                return@runOnUiThread
            }
            val md = c.metadata
            titleTv.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
            artistTv.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val appIcon = try { packageManager.getApplicationIcon(c.packageName) } catch (e: Exception) { null }
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            art.background = shape(0x33FFFFFF, 0x00000000, U(14).toFloat())
            if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(appIcon)
            badge.setImageDrawable(appIcon)
            val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
            btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            spectrum.playing = playing
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun updateProgress() {
        val c = controller ?: return
        val ps = c.playbackState ?: return
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (dur <= 0) { bar.frac = 0f; tPos.text = ""; tDur.text = ""; return }
        val pos = if (ps.state == PlaybackState.STATE_PLAYING)
            ps.position + ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * ps.playbackSpeed).toLong()
        else ps.position
        bar.frac = pos.toFloat() / dur
        tPos.text = fmt(pos.coerceIn(0, dur))
        tDur.text = fmt(dur)
    }

    // =====================================================================
    //  Luces con la música (audio real)
    // =====================================================================
    private fun startVisualizer() {
        if (visualizer != null) return
        try {
            val v = Visualizer(0)
            v.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, wf: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) spectrum.setFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            visualizer = v
        } catch (e: Exception) {
            spectrum.fallback = true // si el equipo no deja leer el audio, se anima con el ritmo simulado mientras suena
        }
    }

    // =====================================================================
    //  Permisos, GPS, velocidad y clima
    // =====================================================================
    private fun requestPerms() {
        val need = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else afterPerms()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        afterPerms()
    }

    private fun afterPerms() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            val last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) fetchWeather(last.latitude, last.longitude)
        } catch (e: Exception) { }
        myLoc.enableMyLocation()
        startVisualizer()
    }

    override fun onLocationChanged(loc: Location) {
        speedRing.value = loc.speed * 3.6f
        if (loc.time > 1600000000000L) gpsOffset = loc.time - System.currentTimeMillis()
        fetchWeather(loc.latitude, loc.longitude)
    }

    private fun weatherText(code: Int): String = when (code) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        in 51..57 -> "Llovizna"
        in 61..67 -> "Lluvia"
        in 71..77 -> "Nieve"
        in 80..82 -> "Chubascos"
        in 95..99 -> "Tormenta"
        else -> "Clima"
    }

    private fun fetchWeather(lat: Double, lon: Double) {
        val now = SystemClock.elapsedRealtime()
        if (lastWeather != 0L && now - lastWeather < 20 * 60 * 1000L) return
        lastWeather = now
        Thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset" +
                    "&timezone=auto&forecast_days=1"
                val j = JSONObject(http(url))
                val cur = j.getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                val daily = j.getJSONObject("daily")
                val mx = Math.round(daily.getJSONArray("temperature_2m_max").getDouble(0)).toInt()
                val mn = Math.round(daily.getJSONArray("temperature_2m_min").getDouble(0)).toInt()
                val sr = daily.getJSONArray("sunrise").getString(0)
                val ss = daily.getJSONArray("sunset").getString(0)
                val srm = sr.substring(11, 13).toInt() * 60 + sr.substring(14, 16).toInt()
                val ssm = ss.substring(11, 13).toInt() * 60 + ss.substring(14, 16).toInt()
                runOnUiThread {
                    sunrise = srm; sunset = ssm
                    wText1.text = weatherText(code)
                    wText2.text = "Mín $mn° · Máx $mx°"
                    tempTv.text = "$t°"
                    wIcon.setImageResource(
                        when (code) { 0, 1 -> R.drawable.ic_sun; 2, 3, 45, 48 -> R.drawable.ic_cloud; else -> R.drawable.ic_rain }
                    )
                    if (prefs.getInt("tema", 0) == 0) applyTheme()
                }
            } catch (e: Exception) {
                lastWeather = 0L
            }
        }.start()
    }

    // =====================================================================
    //  Ciclo de vida
    // =====================================================================
    override fun onResume() {
        super.onResume()
        map.onResume()
        myLoc.enableMyLocation()
        refreshDockIcons()
        hideKeyboard()
        handler.postDelayed({ hideKeyboard() }, 600)
    }

    override fun onPause() {
        super.onPause()
        hideKeyboard()
        map.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        visualizer?.release()
        try { (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this) } catch (e: Exception) { }
    }

    override fun onBackPressed() { if (search.hasFocus()) hideKeyboard() /* es el launcher: no sale */ }
    @Deprecated("") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}
}
