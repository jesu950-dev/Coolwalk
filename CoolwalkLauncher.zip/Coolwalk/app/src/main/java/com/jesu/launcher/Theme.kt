package com.jesu.launcher

class Palette(
    val bg1: Int, val bg2: Int, val bg3: Int,
    val glowA: Int, val glowB: Int, val glowC: Int, val glowD: Int,
    val glass: Int, val stroke: Int, val text: Int, val soft: Int, val accent: Int,
    val musicA: Int, val musicB: Int, val panel: Int, val button: Int, val dock: Int,
    val dark: Boolean
)

object Themes {
    private fun c(v: Long): Int = v.toInt()

    private fun night(
        bg1: Long, bg2: Long, bg3: Long,
        gA: Long, gB: Long, gC: Long, gD: Long,
        musicA: Long, musicB: Long, panel: Long, button: Long, dock: Long, accent: Long
    ) = Palette(
        bg1 = c(bg1), bg2 = c(bg2), bg3 = c(bg3),
        glowA = c(gA), glowB = c(gB), glowC = c(gC), glowD = c(gD),
        glass = c(0xD9101436), stroke = c(0x80FFFFFF), text = c(0xFFFFFFFF),
        soft = c(0xFFD2D7F2), accent = c(accent),
        musicA = c(musicA), musicB = c(musicB), panel = c(panel), button = c(button), dock = c(dock),
        dark = true
    )

    val NAMES = arrayOf("Neón", "Océano", "Atardecer", "Esmeralda", "Rojo deportivo")

    private val nights = listOf(
        // Neón: turquesa, violeta y magenta
        night(0xFF04051A, 0xFF160A44, 0xFF35094F, 0xCC00E0F0, 0xCCFF2BC0, 0xCC8A3DFF, 0xAA2E6BFF,
            0xFF12B4D6, 0xFFE02BB5, 0xE68A35E0, 0xAA3B2A9A, 0xB3592FC4, 0xFF3DE0FF),
        // Océano: celestes y azules
        night(0xFF03101F, 0xFF062449, 0xFF0A3566, 0xCC00D4FF, 0xCC2979FF, 0xCC00BFA5, 0xAA5C6BFF,
            0xFF00B3D9, 0xFF2455D6, 0xE62467C9, 0xAA163C8A, 0xB3154E9C, 0xFF40E0FF),
        // Atardecer: naranja, rosa y violeta
        night(0xFF1A0612, 0xFF3A0B2E, 0xFF5A1230, 0xCCFF7A18, 0xCCFF3D81, 0xCC9B3DFF, 0xAAFFC107,
            0xFFFF8A3D, 0xFFD6246E, 0xE6B8307A, 0xAA6B1F58, 0xB3892A66, 0xFFFFB74D),
        // Esmeralda: verdes
        night(0xFF021510, 0xFF04302A, 0xFF064A3C, 0xCC00E676, 0xCC1DE9B6, 0xCC00B8D4, 0xAA64DD17,
            0xFF00C98D, 0xFF0E7C86, 0xE6118C6A, 0xAA0B5A48, 0xB30E7A5E, 0xFF69F0AE),
        // Rojo deportivo
        night(0xFF0B0507, 0xFF260810, 0xFF420A16, 0xCCFF1744, 0xCCFF6D00, 0xCCD500F9, 0xAAFF5252,
            0xFFFF3D4F, 0xFF8E1450, 0xE6B3203A, 0xAA5A1220, 0xB3801A2E, 0xFFFF6E7A)
    )

    fun night(index: Int): Palette = nights[index.coerceIn(0, nights.size - 1)]

    val DAY = Palette(
        bg1 = c(0xFFCFE8FF), bg2 = c(0xFFE6D6FF), bg3 = c(0xFFFFD6EC),
        glowA = c(0x8060D8FF), glowB = c(0x80FF8AC8), glowC = c(0x808F7CFF), glowD = c(0x8078B4FF),
        glass = c(0xE6FFFFFF), stroke = c(0xCCFFFFFF), text = c(0xFF1B1F3B),
        soft = c(0xFF4A5080), accent = c(0xFF2F6BFF),
        musicA = c(0xFF7FE0F0), musicB = c(0xFFF59AD8),
        panel = c(0xCCFFFFFF), button = c(0xB3FFFFFF), dock = c(0xB3FFFFFF),
        dark = false
    )
}
