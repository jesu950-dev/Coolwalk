package com.jesu.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Luces de espectro con varios estilos. Tocar un lugar vacío cambia el estilo. */
class SpectrumView(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {

    companion object {
        val NAMES = arrayOf("Abanico", "Barras", "Ondas", "Línea", "Bordes", "Aurora", "Apagado")
    }

    var style = 0
    var playing = false
        set(v) { field = v; invalidate() }
    var fallback = false

    private val n = 48
    private val mags = FloatArray(n)
    private val target = FloatArray(n)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rect = RectF()
    private val hsv = FloatArray(3)
    private var lastFft = 0L
    private val d = resources.displayMetrics.density

    fun applyStyle(i: Int) {
        style = i
        invalidate()
    }

    fun setFft(fft: ByteArray) {
        val half = fft.size / 2
        for (i in 0 until n) {
            val f = i / (n - 1f)
            val k = (1 + (half - 3) * f * f).toInt().coerceIn(1, half - 1)
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            val m = sqrt((re * re + im * im).toFloat()) / 80f
            target[i] = min(1f, m * (1f + i * 0.03f))
        }
        lastFft = System.currentTimeMillis()
    }

    private fun color(m: Float, alpha: Int): Int {
        hsv[0] = 130f * (1f - m.coerceIn(0f, 1f)); hsv[1] = 0.85f; hsv[2] = 1f
        return Color.HSVToColor(alpha.coerceIn(0, 255), hsv)
    }

    private fun hue(h: Float, alpha: Int): Int {
        hsv[0] = ((h % 360f) + 360f) % 360f; hsv[1] = 0.8f; hsv[2] = 1f
        return Color.HSVToColor(alpha.coerceIn(0, 255), hsv)
    }

    private fun strokeLine(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, m: Float, w: Float) {
        line.strokeWidth = w * 2f
        line.color = color(m, 50)
        c.drawLine(x1, y1, x2, y2, line)
        line.strokeWidth = w
        line.color = color(m, 235)
        c.drawLine(x1, y1, x2, y2, line)
    }

    override fun onDraw(c: Canvas) {
        if (style >= NAMES.size - 1) return
        val now = System.currentTimeMillis()
        val energy = target.sum() / n
        val live = now - lastFft < 500 && energy > 0.04f
        val t = now / 1000f
        for (i in 0 until n) {
            val goal = when {
                live -> target[i]
                playing && fallback -> (0.2f + 0.7f * abs(sin(t * (1.4f + i % 5 * 0.35f) + i * 0.6f))) * (1f - i * 0.008f)
                else -> 0f
            }
            mags[i] += (goal - mags[i]) * 0.3f
        }
        if (!playing && mags.none { it > 0.02f }) return
        var bass = 0f
        for (i in 0 until 6) bass += mags[i]
        bass /= 6f
        when (style) {
            0 -> fan(c)
            1 -> bars(c)
            2 -> rings(c, bass, t)
            3 -> wave(c, bass)
            4 -> sides(c)
            5 -> aurora(c, bass, t)
        }
        if (playing || mags.any { it > 0.02f }) postInvalidateOnAnimation()
    }

    private fun fan(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val inner = h * 0.06f; val maxLen = h * 0.42f
        for (side in 0..1) {
            val ox = if (side == 0) 0f else w
            for (i in 0 until n) {
                val f = i / (n - 1f)
                val deg = if (side == 0) -90f + 90f * f else -90f - 90f * f
                val a = deg * PI.toFloat() / 180f
                val len = max(6f, mags[i] * maxLen)
                strokeLine(c, ox + cos(a) * inner, h + sin(a) * inner,
                    ox + cos(a) * (inner + len), h + sin(a) * (inner + len), mags[i], 3.5f * d)
            }
        }
    }

    private fun bars(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val bw = w / n
        for (i in 0 until n) {
            val x = (i + 0.5f) * bw
            val len = max(6f, mags[i] * h * 0.32f)
            strokeLine(c, x, h - 4f, x, h - 4f - len, mags[i], bw * 0.28f)
        }
    }

    private fun rings(c: Canvas, bass: Float, t: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        for (side in 0..1) {
            val cx = if (side == 0) 0f else w
            val start = if (side == 0) 270f else 180f
            for (k in 0..3) {
                val m = mags[k * 8]
                val r = h * (0.10f + 0.09f * k) + bass * h * (0.05f + 0.03f * k)
                line.strokeWidth = (3f + m * 12f) * d
                line.color = hue(t * 50f + k * 60f + side * 40f, (90 + 160 * m).toInt())
                rect.set(cx - r, h - r, cx + r, h + r)
                c.drawArc(rect, start, 90f, false, line)
            }
        }
    }

    private fun wave(c: Canvas, bass: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        path.reset()
        var px = 0f
        var py = h - 6f - mags[0] * h * 0.38f
        path.moveTo(px, py)
        for (i in 1 until n) {
            val x = i * w / (n - 1)
            val y = h - 6f - mags[i] * h * 0.38f
            path.quadTo(px, py, (px + x) / 2f, (py + y) / 2f)
            px = x; py = y
        }
        path.lineTo(w, py)
        line.strokeWidth = 4f * d
        line.color = color(bass, 240)
        c.drawPath(path, line)
        path.lineTo(w, h); path.lineTo(0f, h); path.close()
        fill.color = color(bass, 45)
        c.drawPath(path, fill)
    }

    private fun sides(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0 until n) {
            val y = (i + 0.5f) * h / n
            val len = mags[i] * w * 0.10f + 4f
            strokeLine(c, 0f, y, len, y, mags[i], h / n * 0.28f)
            strokeLine(c, w, y, w - len, y, mags[i], h / n * 0.28f)
        }
    }

    private fun aurora(c: Canvas, bass: Float, t: Float) {
        val w = width.toFloat(); val h = height.toFloat()
        val sw = 6f * d + bass * 40f * d
        val col = hue(t * 35f, (70 + bass * 185).toInt())
        rect.set(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f)
        line.strokeWidth = sw * 2.2f
        line.color = hue(t * 35f, 35)
        c.drawRoundRect(rect, 30f * d, 30f * d, line)
        line.strokeWidth = sw
        line.color = col
        c.drawRoundRect(rect, 30f * d, 30f * d, line)
    }
}
