package com.jesu.launcher

class Palette(
    val bg1: Int, val bg2: Int, val bg3: Int,
    val glowA: Int, val glowB: Int, val glowC: Int, val glowD: Int,
    val glass: Int, val stroke: Int, val text: Int, val soft: Int, val accent: Int,
    val musicA: Int, val musicB: Int, val panel: Int, val button: Int, val dock: Int,
    val dark: Boolean
)

object Themes {
    val NIGHT = Palette(
        bg1 = 0xFF05061A.toInt(), bg2 = 0xFF120A3C.toInt(), bg3 = 0xFF2A0B4A.toInt(),
        glowA = 0xB300CDE1.toInt(), glowB = 0xB3EB28AF.toInt(), glowC = 0xB3823CFF.toInt(), glowD = 0x992864FF.toInt(),
        glass = 0xCC14173F.toInt(), stroke = 0x66FFFFFF.toInt(), text = 0xFFFFFFFF.toInt(),
        soft = 0xFFC8CDEB.toInt(), accent = 0xFF46AFFF.toInt(),
        musicA = 0xCC1AA9C9.toInt(), musicB = 0xDDD832B8.toInt(),
        panel = 0xCC7A32D2.toInt(), button = 0x992D2575.toInt(), dock = 0x99502DAA.toInt(),
        dark = true
    )
    val DAY = Palette(
        bg1 = 0xFFCFE8FF.toInt(), bg2 = 0xFFE6D6FF.toInt(), bg3 = 0xFFFFD6EC.toInt(),
        glowA = 0x8060D8FF.toInt(), glowB = 0x80FF8AC8.toInt(), glowC = 0x808F7CFF.toInt(), glowD = 0x8078B4FF.toInt(),
        glass = 0xCCFFFFFF.toInt(), stroke = 0xCCFFFFFF.toInt(), text = 0xFF1B1F3B.toInt(),
        soft = 0xFF4A5080.toInt(), accent = 0xFF2F6BFF.toInt(),
        musicA = 0xCC7FE0F0.toInt(), musicB = 0xCCF59AD8.toInt(),
        panel = 0xCCFFFFFF.toInt(), button = 0xB3FFFFFF.toInt(), dock = 0xB3FFFFFF.toInt(),
        dark = false
    )
}
