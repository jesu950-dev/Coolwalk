package com.carlauncher.coolwalk

import android.Manifest
import android.animation.ValueAnimator
import android.content.*
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.concurrent.Executors

private data class AppTheme(
    val name: String, val bg: Int, val card: Int, val accent: Int, val text: Int,
    val m1: Int, val m2: Int, val m3: Int, val blobA: Int, val blobB: Int
)

private val THEMES = listOf(
    AppTheme("Carbón Turquesa", 0xFF121212.toInt(), 0xFF1C1C1E.toInt(), 0xFF00F5D4.toInt(), 0xFFE5E5E5.toInt(), 0xFF005F73.toInt(), 0xFF4A1A7A.toInt(), 0xFF7B2CBF.toInt(), 0xFFD81B8A.toInt(), 0xFF00828A.toInt()),
    AppTheme("Negro Azulado", 0xFF0A0E17.toInt(), 0xFF111827.toInt(), 0xFF38BDF8.toInt(), 0xFFE5E5E5.toInt(), 0xFF0B2545.toInt(), 0xFF13315C.toInt(), 0xFF1E6091.toInt(), 0xFF3B82F6.toInt(), 0xFF0EA5E9.toInt()),
    AppTheme("Medianoche Violeta", 0xFF0F0A1A.toInt(), 0xFF1A1325.toInt(), 0xFFC084FC.toInt(), 0xFFEDE9FE.toInt(), 0xFF2E1065.toInt(), 0xFF4C1D95.toInt(), 0xFF6D28D9.toInt(), 0xFFDB2777.toInt(), 0xFF7C3AED.toInt()),
    AppTheme("Ámbar Nocturno", 0xFF140E0A.toInt(), 0xFF1E1612.toInt(), 0xFFFFB703.toInt(), 0xFFF5E9DA.toInt(), 0xFF7C2D12.toInt(), 0xFF9A3412.toInt(), 0xFFB45309.toInt(), 0xFFDC2626.toInt(), 0xFFF59E0B.toInt())
)

class MainActivity : AppCompatActivity() {

    companion object {
        // >>> PON AQUÍ TU API KEY de https://openweathermap.org/api <<<
        private const val OWM_KEY = "fb59931eaffe800adb5c9e886c6481c9"
        private const val WEATHER_INTERVAL_MS = 45L * 60 * 1000
        private const val W_DEFAULT = 0.6f
        private const val W_EXPANDED = 0.7f

        // Acciones de iluminación del coche. Cada fabricante usa las suyas (XY Auto / Chinese HU):
        // averigua cuáles emite tu unidad con `adb shell dumpsys activity broadcasts` y añádelas.
        private val ILLUM_ACTIONS = arrayOf(
            "com.carlauncher.ACTION_HEADLIGHTS" // ← reemplazar/añadir acciones reales de tu F9212B
        )
        private const val NIGHT_BRIGHTNESS = 0.25f
    }

    private lateinit var root: LinearLayout
    private lateinit var mapCard: android.view.View
    private lateinit var rightColumn: android.view.View
    private lateinit var map: MapView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPlay: ImageButton
    private lateinit var tvSpeed: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvWeatherIcon: TextView
    private lateinit var musicCard: android.view.View
    private lateinit var infoCard: android.view.View
    private lateinit var clock: TextClock
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnTheme: ImageButton
    private var themeIdx = 0

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var expanded = false
    private var nightManual: Boolean? = null // null = automático
    private var nightByCar = false

    private var marker: Marker? = null
    private var lat = Double.NaN
    private var lon = Double.NaN
    private var firstFix = true

    private lateinit var lm: LocationManager
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerCn: ComponentName
    private var controller: MediaController? = null

    // ---------------- Ciclo de vida ----------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
            tileFileSystemCacheMaxBytes = 100L * 1024 * 1024
            cacheMapTileCount = 12 // pocos tiles en RAM
        }
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        mapCard = findViewById(R.id.mapCard)
        rightColumn = findViewById(R.id.rightColumn)
        map = findViewById(R.id.map)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        progress = findViewById(R.id.progress)
        btnPlay = findViewById(R.id.btnPlay)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvTemp = findViewById(R.id.tvTemp)
        tvWeatherIcon = findViewById(R.id.tvWeatherIcon)
        musicCard = findViewById(R.id.musicCard)
        infoCard = findViewById(R.id.infoCard)
        clock = findViewById(R.id.clock)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        btnTheme = findViewById(R.id.btnTheme)

        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerCn = ComponentName(this, MediaListenerService::class.java)

        setupMap()
        setupControls()
        ensureLocationPermission()
        themeIdx = getSharedPreferences("prefs", MODE_PRIVATE).getInt("theme", 0).coerceIn(0, THEMES.size - 1)
        applyTheme(themeIdx)
        btnTheme.setOnClickListener {
            themeIdx = (themeIdx + 1) % THEMES.size
            getSharedPreferences("prefs", MODE_PRIVATE).edit().putInt("theme", themeIdx).apply()
            applyTheme(themeIdx)
            Toast.makeText(this, THEMES[themeIdx].name, Toast.LENGTH_SHORT).show()
        }
        applyNight()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        startLocation()
        refreshSessions()
        try { msm.addOnActiveSessionsChangedListener(sessionsListener, listenerCn) } catch (_: SecurityException) {}
        registerReceiver(illumReceiver, IntentFilter().apply { ILLUM_ACTIONS.forEach { addAction(it) } })
        main.post(weatherTask)
        main.post(progressTask)
        applyNight()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
        try { lm.removeUpdates(locListener) } catch (_: SecurityException) {}
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        try { unregisterReceiver(illumReceiver) } catch (_: Exception) {}
        controller?.unregisterCallback(mediaCallback)
        controller = null
        main.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        map.onDetach()
        io.shutdownNow()
    }

    @Deprecated("Launcher: ignorar atrás")
    override fun onBackPressed() { /* launcher: no salir */ }

    // ---------------- Mapa ----------------
    private fun setupMap() {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.setUseDataConnection(true)
        map.isTilesScaledToDpi = false
        map.controller.setZoom(16.0)
        map.controller.setCenter(GeoPoint(19.4326, -99.1332)) // centro inicial; se reemplaza con el 1er fix GPS
        marker = Marker(map).apply {
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            map.overlays.add(this)
        }
        // clip redondeado (barato, sin blur)
        mapCard.clipToOutline = true

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleMap(); return true }
        })
        map.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); false } // el mapa sigue haciendo pan/zoom
    }

    private fun toggleMap() {
        expanded = !expanded
        val mapLp = mapCard.layoutParams as LinearLayout.LayoutParams
        val rightLp = rightColumn.layoutParams as LinearLayout.LayoutParams
        val to = if (expanded) W_EXPANDED else W_DEFAULT
        ValueAnimator.ofFloat(mapLp.weight, to).apply {
            duration = 250
            addUpdateListener {
                val w = it.animatedValue as Float
                mapLp.weight = w
                rightLp.weight = 1f - w
                root.requestLayout()
            }
            start()
        }
    }

    // ---------------- Música (MediaSession) ----------------
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { bind(it) }

    private fun refreshSessions() {
        try {
            bind(msm.getActiveSessions(listenerCn))
        } catch (_: SecurityException) {
            tvTitle.text = "Sin acceso a multimedia"
            tvArtist.text = "Toca aquí para conceder acceso"
        }
    }

    private fun bind(list: List<MediaController>?) {
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (pick?.sessionToken == controller?.sessionToken) return
        controller?.unregisterCallback(mediaCallback)
        controller = pick
        pick?.registerCallback(mediaCallback)
        updateMeta(pick?.metadata)
        updateState(pick?.playbackState)
    }

    private val mediaCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateMeta(metadata)
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateState(state)
        override fun onSessionDestroyed() { controller = null; refreshSessions() }
    }

    private fun updateMeta(m: MediaMetadata?) {
        tvTitle.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin reproducción"
        tvArtist.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
    }

    private fun updateState(s: PlaybackState?) {
        btnPlay.setImageResource(if (s?.state == PlaybackState.STATE_PLAYING) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private val progressTask = object : Runnable {
        override fun run() {
            val c = controller
            val s = c?.playbackState
            val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (s != null && dur > 0) {
                var pos = s.position
                if (s.state == PlaybackState.STATE_PLAYING)
                    pos += ((SystemClock.elapsedRealtime() - s.lastPositionUpdateTime) * s.playbackSpeed).toLong()
                progress.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
            } else progress.progress = 0
            main.postDelayed(this, 1000)
        }
    }

    private fun setupControls() {
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener {
            controller?.transportControls?.skipToPrevious() ?: sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener {
            controller?.transportControls?.skipToNext() ?: sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
        btnPlay.setOnClickListener {
            val c = controller
            if (c == null) { sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return@setOnClickListener }
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        val openAccess = android.view.View.OnClickListener {
            if (controller == null) startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        tvTitle.setOnClickListener(openAccess)
        tvArtist.setOnClickListener(openAccess)
        // Pulsación larga en el reloj: alterna modo noche manual (auto → noche → día → auto)
        findViewById<android.view.View>(R.id.clock).setOnLongClickListener {
            nightManual = when (nightManual) { null -> true; true -> false; else -> null }
            applyNight()
            Toast.makeText(this, when (nightManual) { null -> "Noche: auto"; true -> "Noche: ON"; else -> "Noche: OFF" }, Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun sendKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---------------- GPS / Velocímetro ----------------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) Math.round(loc.speed * 3.6f) else 0
            tvSpeed.text = "$kmh km/h"
            lat = loc.latitude; lon = loc.longitude
            val p = GeoPoint(lat, lon)
            marker?.position = p
            if (firstFix || (expanded && kmh > 5)) { map.controller.setCenter(p); firstFix = false }
            map.invalidate()
        }
        @Deprecated("") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
    }

    private fun ensureLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        startLocation()
    }

    private fun startLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener) } catch (_: Exception) {}
    }

    // ---------------- Clima (cada 45 min) ----------------
    private val weatherTask = object : Runnable {
        override fun run() {
            if (lat.isNaN()) { main.postDelayed(this, 30_000); return } // aún sin fix: reintentar pronto
            val la = lat; val lo = lon
            io.execute {
                try {
                    val url = URL("https://api.openweathermap.org/data/2.5/weather?lat=$la&lon=$lo&units=metric&appid=$OWM_KEY")
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    c.disconnect()
                    val j = JSONObject(body)
                    val t = Math.round(j.getJSONObject("main").getDouble("temp")).toInt()
                    val id = j.getJSONArray("weather").getJSONObject(0).getInt("id")
                    main.post { tvTemp.text = "$t°"; tvWeatherIcon.text = emoji(id) }
                } catch (_: Exception) { /* sin red: conservar último valor */ }
            }
            main.postDelayed(this, WEATHER_INTERVAL_MS)
        }
    }

    private fun emoji(id: Int) = when {
        id in 200..232 -> "⛈"; id in 300..321 -> "🌦"; id in 500..531 -> "🌧"
        id in 600..622 -> "❄"; id in 700..781 -> "🌫"; id == 800 -> "☀"; else -> "☁"
    }

    // ---------------- Temas ----------------
    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun meshDrawable(t: AppTheme): LayerDrawable {
        val d = resources.displayMetrics.density
        val r = 16f * d
        val base = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(t.m1, t.m2, t.m3)).apply { cornerRadius = r }
        fun blob(c: Int, cx: Float, cy: Float, rad: Float) = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            setGradientCenter(cx, cy)
            gradientRadius = rad
            colors = intArrayOf(withAlpha(c, 0xB0), withAlpha(c, 0))
            cornerRadius = r
        }
        return LayerDrawable(arrayOf(base, blob(t.blobA, 0.85f, 0.15f, 260f * d), blob(t.blobB, 0.1f, 0.95f, 240f * d)))
    }

    private fun applyTheme(i: Int) {
        val t = THEMES[i]
        val r = 16f * resources.displayMetrics.density
        fun card() = GradientDrawable().apply { setColor(t.card); cornerRadius = r }
        root.setBackgroundColor(t.bg)
        mapCard.background = card()
        infoCard.background = card()
        musicCard.background = meshDrawable(t)
        tvTitle.setTextColor(t.text)
        tvArtist.setTextColor(withAlpha(t.text, 0xB3))
        clock.setTextColor(t.text)
        tvTemp.setTextColor(t.text)
        tvSpeed.setTextColor(t.accent)
        progress.progressTintList = ColorStateList.valueOf(t.accent)
        progress.progressBackgroundTintList = ColorStateList.valueOf(withAlpha(t.text, 0x40))
        btnPlay.setColorFilter(t.accent)
        btnPrev.setColorFilter(t.text)
        btnNext.setColorFilter(t.text)
    }

    // ---------------- Modo noche ----------------
    private val illumReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // Ajusta las claves a lo que emita tu unidad (state / on / illum…)
            nightByCar = i.getBooleanExtra("on", i.getIntExtra("state", 0) == 1)
            applyNight()
        }
    }

    private fun isNight(): Boolean {
        nightManual?.let { return it }
        if (nightByCar) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) // respaldo por hora si no hay señal del coche
        return h >= 19 || h < 6
    }

    private fun applyNight() {
        val night = isNight()
        val lp = window.attributes
        lp.screenBrightness = if (night) NIGHT_BRIGHTNESS else android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        map.overlayManager.tilesOverlay.setColorFilter(if (night) TilesOverlay.INVERT_COLORS else null)
        map.invalidate()
    }
}
