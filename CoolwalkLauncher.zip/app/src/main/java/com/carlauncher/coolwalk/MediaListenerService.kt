package com.carlauncher.coolwalk

import android.service.notification.NotificationListenerService

/** Vacío a propósito: solo sirve para que Android otorgue acceso a MediaSessionManager. */
class MediaListenerService : NotificationListenerService()
